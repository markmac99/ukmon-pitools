# tests for ukmonInstaller

import sys
import os
import shutil
sys.path.append('../RMS')
sys.path.append('.')


from ukmonInstaller import createDefaultIni, updateHelperIp, updateLocation, checkPostProcSettings # noqa: E402
myloc = os.path.split(os.path.abspath(__file__))[0]
homedir = os.path.join(myloc, 'ukminst')
os.makedirs(homedir, exist_ok=True)


def test_createDefaultIni():
    createDefaultIni(homedir)
    lis = open(os.path.join(homedir,'ukmon.ini'), 'r').readlines()
    for li in lis:
        if 'RMSCFG' in li:
            assert li == 'export RMSCFG=~/source/RMS/.config\n'
            return 
    return 


def test_updateHelperIp():
    createDefaultIni(homedir)
    updateHelperIp(homedir, '1.1.1.1')
    lis = open(os.path.join(homedir,'ukmon.ini'), 'r').readlines()
    for li in lis:
        if 'UKMONHELPER' in li:
            assert li == 'export UKMONHELPER=1.1.1.1\n'
            return 
    return 


def test_updateLocation():
    createDefaultIni(homedir)
    updateLocation(homedir, 'plinkshire_w')
    lis = open(os.path.join(homedir,'ukmon.ini'), 'r').readlines()
    for li in lis:
        if 'LOCATION' in li:
            assert li == 'export LOCATION=plinkshire_w\n'
            return 
    return 


def test_checkPostProcSettings():
    origcfg = os.path.join(homedir, '.config.orig')
    rmscfg = os.path.join(homedir, '.config')
    if os.path.isfile(rmscfg):
        os.remove(rmscfg)
    shutil.copyfile(origcfg, rmscfg)
    checkPostProcSettings(homedir, rmscfg)
    scrname = os.path.join(homedir, 'ukmonPostProc.py')
    lis = open(os.path.join(homedir,'ukmon.ini'), 'r').readlines()
    for li in lis:
        if 'auto_reprocess_external_script_run: ' in li:
            assert li == 'auto_reprocess_external_script_run: true  \n'
        if 'external_script_path: ' in li:
            assert li == 'external_script_path: {}  \n'.format(scrname)
        if 'external_script_run: ' in li and 'auto_reprocess_' not in li:
            assert li == 'external_script_run: true  \n'
        if 'auto_reprocess: ' in li:
            assert li == 'auto_reprocess: true  \n'
    return
